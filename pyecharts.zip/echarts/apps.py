from django.apps import AppConfig


class EchartsConfig(AppConfig):
    name = 'echarts'
